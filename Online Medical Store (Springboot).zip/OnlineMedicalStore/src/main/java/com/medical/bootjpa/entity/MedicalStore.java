package com.medical.bootjpa.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name = "MedicalStore")
@NamedQuery(name = "findMedicalStorerecords", query = "select sr from MedicalStore sr")
public class MedicalStore
{
	@Id //primary key
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long storeId;
	@Column (name= "Store_Name")
	private String storeName;
	@Column (name= "Store_Address")
	private String storeAdd;
	@Column (name= "Store_City")
	private String city;
	@Column (name= "Store_Phone")
	private String phone;
	@Column (name= "Store_Email")
	private String email;


	public Long getStoreId() {
		return storeId;
	}
	public void setStoreId(Long storeId) {
		this.storeId = storeId;
	}
	public String getStoreName() {
		return storeName;
	}
	public void setStoreName(String storeName) {
		this.storeName = storeName;
	}
	public String getStoreAdd() {
		return storeAdd;
	}
	public void setStoreAdd(String storeAdd) {
		this.storeAdd = storeAdd;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}



}
