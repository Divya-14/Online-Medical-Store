package com.medical.bootjpa.service;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.medical.bootjpa.entity.OrderFeedback;
import com.medical.bootjpa.repository.OrderFeedbackRepository;
@Service("orderfeedbackServiceImpl")
public class OrderFeedbackServiceImpl implements OrderFeedbackService{
	@Autowired
	private OrderFeedbackRepository orderfeedbackRepository;
	
	@Override
	public void addOrderFeedback(OrderFeedback orderf) {
		orderfeedbackRepository.save(orderf);
	}
	//--------------------------------------------------------------------------------------------

	@Override
	public OrderFeedback addOrderFeedback1(OrderFeedback of) {
		return orderfeedbackRepository.save(of);
	}

	@Override
	public List<OrderFeedback> getOrderFeedbacks() {
			return orderfeedbackRepository.findAll();
	}

	@Override
	public void deleteOrderFeedback(Long id) {
		orderfeedbackRepository.delete(id);	
	}
}