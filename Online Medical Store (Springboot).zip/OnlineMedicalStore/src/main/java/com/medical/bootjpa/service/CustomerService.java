package com.medical.bootjpa.service;
import com.medical.bootjpa.entity.Customer;
public interface CustomerService {
	public	void addCustomer(Customer cust);
	public String selectCustomerById(Long custid);
	public Customer getCustomerById(Long id);
}