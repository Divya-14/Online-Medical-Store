package com.medical.bootjpa;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.Scanner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import com.medical.bootjpa.controller.CustomerController;
import com.medical.bootjpa.controller.MedicalController;
import com.medical.bootjpa.controller.OrderFeedbackController;
import com.medical.bootjpa.controller.OrderMedicineController;
import com.medical.bootjpa.entity.Address;
import com.medical.bootjpa.entity.Customer;
import com.medical.bootjpa.entity.MedicalStore;
import com.medical.bootjpa.entity.OrderFeedback;
import com.medical.bootjpa.entity.OrderMedicine;
@ComponentScan(basePackages = "com.*")
@EntityScan("com.medical.bootjpa.entity")
@SpringBootApplication
public class MedicalStore1Application {
	static Long dummyId=null;
	Long dummy1=null;
	public static MedicalStore getMedicalStoreDetails(Scanner sc)
	{
		System.out.println("Enter MedicalStoreName:");
		String sname=sc.next();
		System.out.println("Enter  StoreAddress:");
		String add=sc.next();
		System.out.println("Enter City:");
		String city=sc.next();
		System.out.println("Enter phone:");
		String phone=sc.next();
		System.out.println("Enter Email:");
		String email=sc.next();
		MedicalStore  medical=new MedicalStore();
		medical.setStoreName(sname);
		medical.setStoreAdd(add);
		medical.setCity(city);
		medical.setPhone(phone);
		medical.setEmail(email);		
		return medical;

	}
	public static Customer getCustomerDetails(Scanner sc)
	{
		System.out.println("Enter Customer Name:");
		String cname=sc.next();
		System.out.println("Enter Customer Phone :");
		String cphone=sc.next();
		System.out.println("Enter Customer Email");
		String cemail=sc.next();
		System.out.println("Enter Customer Address:");
		String cadd=sc.next();
		System.out.println("Enter Customer City:");
		String ccity=sc.next();
		System.out.println("Enter Customer Password:");
		String cpsw=sc.next();
		System.out.println("Enter Building:");
		String build=sc.next();
		System.out.println("Enter Street:");
		String street=sc.next();
		System.out.println("Enter State:");
		String state=sc.next();
		System.out.println("Enter Country:");
		String country=sc.next();
		System.out.println("Enter Zipcode:");
		String zcode=sc.next();
		Address addr=new Address();
		addr.setBuilding(build);
		addr.setStreet(street);
		addr.setState(state);
		addr.setCountry(country);
		addr.setZipcode(zcode);
		Customer cust=new Customer();
		cust.setCustomerName(cname);
		cust.setCustomerPhone(cphone);
		cust.setCustomerEmail(cemail);		
		cust.setCustomerCity(ccity);
		cust.setCustomerPassword(cpsw);
		cust.setAddress(addr);
		return cust;		
	}
	public static ArrayList loginCustomer(Scanner sc)
	{
		System.out.println("Customer Id:");
		Long custid=sc.nextLong();
		dummyId=custid;
		System.out.println("Customer Password:");
		String cpsw=sc.next();
		ArrayList customerDetails=new ArrayList();
		customerDetails.add(custid);
		customerDetails.add(cpsw);
		return customerDetails;
	}
	public static OrderMedicine getOrderMedicineDetails(Scanner sc)
	{
		int sum=0;
		System.out.println("please select storeId:");
		Long storeId=sc.nextLong();
		Long dummy1=storeId;
		System.out.println("Following medicines are available-");
		System.out.println("1. paracetamol----rs 5");
		System.out.println("2. coldact----rs 8");
		System.out.println("3. vicks----rs 4");
		System.out.println("4.sinarest----rs 6");
		System.out.println("5.Dolo----rs 3");
		HashMap<Integer,Integer> hm=new HashMap<Integer,Integer>();
		hm.put(1,5);
		hm.put(2,8);
		hm.put(3,4);
		hm.put(4,6);
		hm.put(5,3);
		@SuppressWarnings("unused")
		String ch2="y";
		char c1;
		do
		{
			System.out.println("please enter medicine code:");
			String mname=sc.next();
			System.out.println("please enter quantity:");
			int quantity=sc.nextInt();
			@SuppressWarnings("deprecation")
			int price=quantity*hm.get(new Integer(mname));
			sum=sum+price;
			System.out.println("Total BillAmount="+sum);
			System.out.println("Do you want to continue:");
			c1=sc.next().charAt(0);
		}
		while(c1=='y');

		Date date=new Date();
		SimpleDateFormat formatter=new SimpleDateFormat("MM/dd/yyyy");
		String strDate=formatter.format(date);
		Calendar c=Calendar.getInstance();
		System.out.println(c.getTime());
		@SuppressWarnings("unused")

		OrderMedicine orderm=new  OrderMedicine();
		orderm.setCustomerId(dummyId);
		orderm.setBillAmount(sum);
		orderm.setStoreId(dummy1);
		orderm.setDate(strDate);
		orderm.setPaymentStatus("No");
		return orderm;
	}
	public static Long getOrderPaymentDetails(Scanner sc)
	{
		System.out.println("please Enter OrderId");
		Long ordermid=sc.nextLong();
		System.out.println("please Select PaymentMode(OnlineBanking/UPI/Cash)");
		String pm=sc.next();
		return ordermid;
	}
	public static OrderFeedback getOrderFeedbackDetails(Scanner sc)
	{
		System.out.println("Enter your CustomerId");
		String custid=sc.next();
		System.out.println("Enter your Feedback:");
		String fb=sc.next();
		OrderFeedback orderf=new OrderFeedback();
		orderf.setCustomerId(dummyId);
		orderf.setFeedback(fb);
		return orderf;

	}
	public static void main(String[] args) {
		ApplicationContext ctx=SpringApplication.run(MedicalStore1Application.class, args);
		Scanner sc=new Scanner(System.in);
		System.out.println("Online Medical Store:");
		System.out.println("---------------------");
		char ca;	
		do
		{
			try
			{
				System.out.println("1.Admin");
				System.out.println("2.Customer");
				System.out.println("3.Exit");
				System.out.println("Please Select Option:");
				int opt=sc.nextInt();
				if(opt==1)
				{
					System.out.println("Admin Id:");
					String id=sc.next();
					System.out.println("Admin Password:");
					String pwd=sc.next();
					if(id.equals("admin")&&pwd.equals("admin"))
					{
						char ca1;
						MedicalController medicalctrl=ctx.getBean(MedicalController.class);
						do
						{
							try 
							{
								System.out.println("1.Medical Store Registration:");
								System.out.println("2.Get Medical Store details  by city");
								System.out.println("3.Admin Logout");
								System.out.println("Please select option:");
								int opt1=sc.nextInt();
								char c;								
								do
								{
									if(opt1==1)
									{	

										MedicalStore medical=getMedicalStoreDetails(sc);
										medicalctrl.insertMedicalStoreRecords(medical);
									}
									else if(opt1==2)
									{
										System.out.println("Enter city");
										String medicalcity=sc.next();
										medicalctrl.getStoreCity(medicalcity);

									}
									else if(opt1==3)
									{
										break;
									}
									System.out.println("Do you want to continue:");
									c=sc.next().charAt(0);
								}
								while(c=='y');
							}
							catch(InputMismatchException e)
							{
								System.out.println("Invalid Input");
								System.out.println("please enter 1 and 2  option");
							}
							System.out.println("Do you want to continue:");
							ca1=sc.next().charAt(0);
						}
						while(ca1=='y');
					}
				}
				else if(opt==2)
				{	
					char ca2;
					CustomerController custctrl = ctx.getBean(CustomerController.class);
					do
					{
						System.out.println("1.Customer Registration");
						System.out.println("2.Customer Login");
						System.out.println("3.Customer Logout");
						System.out.println("Please select option:");
						int copt=sc.nextInt();
						if(copt==1)
						{
							Customer cust=getCustomerDetails(sc);
							custctrl.insertCustomerRecords(cust);
						}
						else if(copt==2)
						{
							ArrayList<Comparable> customerDetails=loginCustomer(sc);
							String originalpsw=custctrl.getCustomerLoginPassword((Long)customerDetails.get(0));
							if(originalpsw==null)
							{
								try
								{
									throw new CustomerNotFoundException();
								} catch(CustomerNotFoundException e)
								{

								}
							}
							else {
								if(originalpsw.equals((String)customerDetails.get(1)))
								{
									{
										System.out.println(custctrl.getCustomerById(new Long(1)));
									}
									MedicalController medicalctrl1=ctx.getBean(MedicalController.class);
									OrderMedicineController ordermctrl=ctx.getBean(OrderMedicineController.class);
									OrderFeedbackController orderfctrl=ctx.getBean(OrderFeedbackController.class);

									System.out.println("1.Order Medicine");
									System.out.println("2.Order Payment");
									System.out.println("3.Medical Store Feedback ");
									System.out.println("4.Customer logout");
									System.out.println("please select option:");
									int ch=sc.nextInt();
									if(ch==1) 
									{
										medicalctrl1.fetchAllMedicalStore();
										OrderMedicine orderm=getOrderMedicineDetails(sc);
										Long originalstoreid = medicalctrl1.getMedicalStoreId(orderm.getStoreId());
										if(originalstoreid==null) 
										{
											try
											{
												throw new StoreNotFoundException();
											}
											catch(StoreNotFoundException e)
											{

											}
										}
										else {
											ordermctrl.insertOrderMedicineRecords(orderm);
										}
									}
									else if(ch==2)
									{
										Long orderid=getOrderPaymentDetails(sc);
										System.out.println(ordermctrl.getOrderMedicineById(new Long(1)));
										ordermctrl.updateOrderMedicine("yes",orderid);
									}								
									else if(ch==3)
									{
										OrderFeedback orderf=getOrderFeedbackDetails(sc);
										orderfctrl.insertOrderFeedbackRecords(orderf);
									}
									else if(ch==4) {
										break;

									}
								} 
								else {
									System.out.println("Invalid Customer Password");
								}
							}
						}
						else if(copt==3)
						{
							break;
						}

						else 
						{
							System.out.println("invalid option:");
							System.out.println("please enter 1 and 2 options");
						}
						System.out.println("Do you want to continue:");
						ca2=sc.next().charAt(0);
					}
					while(ca2=='y');
				}
				else if(opt==3)
				{
					break;
				}
				else
				{
					System.out.println("Invalid option");
					System.out.println("please enter 1 and 2 options");
				}	
			}			
			catch(InputMismatchException e)
			{
				System.out.println("Invalid Input");
				System.out.println("please enter 1 and 2 options");
			}
			System.out.println("Do you want to continue:");
			ca=sc.next().charAt(0);
		}
		while(ca=='y');
	}
}