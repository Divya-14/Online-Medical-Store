package com.medical.bootjpa.service;
import java.util.List;
import com.medical.bootjpa.entity.OrderFeedback;
public interface OrderFeedbackService {
	public void addOrderFeedback(OrderFeedback orderf);
	//-----------------------------------------------------------------------------
	public OrderFeedback addOrderFeedback1(OrderFeedback of);
	public List <OrderFeedback> getOrderFeedbacks();
	public void deleteOrderFeedback(Long id);
}