package com.medical.bootjpa;

@SuppressWarnings("serial")
public class CustomerNotFoundException extends Exception {
	public CustomerNotFoundException() {
		System.out.println("Customer doesn't exists in database.");
	}

}
