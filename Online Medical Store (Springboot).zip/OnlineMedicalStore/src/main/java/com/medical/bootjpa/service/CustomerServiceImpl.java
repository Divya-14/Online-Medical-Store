package com.medical.bootjpa.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.medical.bootjpa.entity.Customer;
import com.medical.bootjpa.entity.MedicalStore;
import com.medical.bootjpa.repository.CustomerRepository;
import com.medical.bootjpa.repository.MedicalRepository;
@Service("customerServiceImpl")
public   class CustomerServiceImpl implements CustomerService{
	@Autowired
	private CustomerRepository customerRepository;

	@Override
	public void addCustomer(Customer cust)
	{
		customerRepository.save(cust);
	}

	@Override
	public String selectCustomerById(Long custid) {
		String psw=customerRepository.selectCustomerById(custid);
		return psw;
		
	}

	@Override
	public Customer getCustomerById(Long id) {
		Customer cust=customerRepository.findOne(id);
		return cust;
	}
}