package com.medical.bootjpa.config;


import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

public class MedicalConfig {
	@Configuration
	@EnableJpaRepositories(basePackages = "com.medical.bootjpa.repository")
	public class JPAConfig {

	}
}
