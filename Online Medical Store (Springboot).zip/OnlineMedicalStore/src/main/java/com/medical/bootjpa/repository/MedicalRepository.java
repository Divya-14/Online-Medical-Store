package com.medical.bootjpa.repository;
import java.util.ArrayList;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import com.medical.bootjpa.entity.MedicalStore;
@Repository
public interface MedicalRepository extends JpaRepository<MedicalStore, Long>{
	@Transactional
	@Query("from MedicalStore medical where medical.city= :medicalstorecity ")
	ArrayList<MedicalStore> selectStoreByCity(@Param("medicalstorecity") String city);
	@Transactional
	@Query("from MedicalStore medical")
	ArrayList<MedicalStore> fetchAll();
	@Transactional
	@Query("select medical.storeId from MedicalStore medical where medical.storeId= :storeId")
	Long selectMedicalStoreById(@Param("storeId") Long id);
}