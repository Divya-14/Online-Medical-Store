package com.medical.bootjpa;

public class StoreNotFoundException extends Exception{
	public StoreNotFoundException() {
		System.out.println("Store doesn't exits in database.");
	}

}
