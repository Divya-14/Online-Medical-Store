package com.medical.bootjpa.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import com.medical.bootjpa.entity.OrderMedicine;
@Repository
public interface OrderMedicineRepository extends JpaRepository<OrderMedicine,Long> {
	@Transactional
	@Modifying
	@Query("update OrderMedicine orderm set orderm.paymentStatus= :paystatus where orderm.OrderId=:ordermid")
	void updatePaymentStatusById(@Param("paystatus") String paystatus,@Param("ordermid") Long id);
}