package com.medical.bootjpa.service;
import java.util.List;

import com.medical.bootjpa.entity.OrderMedicine;
public interface OrderMedicineService {
	public	void addOrderMedicine(OrderMedicine orderm);
	public void updatePaymentStatusById(String paystatus,Long id);
	public OrderMedicine getOrderMedicineById(Long id);
	//------------------------------------------------------------------------------------
	public  OrderMedicine addOrderMedicine1(OrderMedicine om);
	public List <OrderMedicine> getOrderMedicines();
	public void deleteOrderMedicine(Long id);
}