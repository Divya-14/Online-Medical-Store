package com.medical.bootjpa.service;
import java.util.ArrayList;
import java.util.List;
import com.medical.bootjpa.entity.MedicalStore;
public interface MedicalService 
{
	public	void addMedicalStore(MedicalStore medical);
	public  ArrayList<MedicalStore> selectStoreByCity(String storecity);
	ArrayList<MedicalStore> fetchAll();
	public Long selectMedicalStoreById(Long storeId);
	//--------------------------------------------------------------------------------------
	public MedicalStore addMedicalStore1(MedicalStore m);
	public List <MedicalStore> getMedicalStores();
	public void deleteMedicalStore(Long id);
}