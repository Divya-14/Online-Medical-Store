package com.medical.bootjpa.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import com.medical.bootjpa.entity.Customer;
@Repository
public interface CustomerRepository extends JpaRepository<Customer,Long> {
	@Transactional
	@Query("select cust.customerPassword from Customer cust where cust.customerId=:custid")
	String selectCustomerById(@Param("custid") Long id);

}