package com.medical.bootjpa.service;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.medical.bootjpa.entity.MedicalStore;
import com.medical.bootjpa.repository.MedicalRepository;
@Service("medicalstoreServiceImpl")
public   class MedicalServiceImpl implements MedicalService{
	@Autowired
	private MedicalRepository medicalstoreRepository;
	@Override
	public void addMedicalStore(MedicalStore medical)
	{
		medicalstoreRepository.save(medical);
	}
	@Override
	public ArrayList<MedicalStore> selectStoreByCity(String storecity) {
		ArrayList<MedicalStore> medicalcity=medicalstoreRepository.selectStoreByCity(storecity);
		return medicalcity;
	}
	@Override
	public ArrayList<MedicalStore> fetchAll() {
		ArrayList<MedicalStore> al=medicalstoreRepository.fetchAll();
		return al;
	}
	@Override
	public Long selectMedicalStoreById(Long storeId) {
		Long stid = medicalstoreRepository.selectMedicalStoreById(storeId);
		return stid;
	}
//-----------------------------------------------------------------------------------------------------------------

	@Override
	public MedicalStore addMedicalStore1(MedicalStore m) {
		return medicalstoreRepository.save(m);
	}
	@Override
	public List<MedicalStore> getMedicalStores() {
		return medicalstoreRepository.findAll() ;
	}
	@Override
	public void deleteMedicalStore(Long id) {
		medicalstoreRepository.delete(id);		
	}
}