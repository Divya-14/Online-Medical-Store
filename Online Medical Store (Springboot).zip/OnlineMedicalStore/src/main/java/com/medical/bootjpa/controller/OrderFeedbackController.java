package com.medical.bootjpa.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import com.medical.bootjpa.entity.MedicalStore;
import com.medical.bootjpa.entity.OrderFeedback;
import com.medical.bootjpa.service.OrderFeedbackService;
@RestController
@RequestMapping(value = "/OrderFeedback")
public class OrderFeedbackController {
	@Autowired
	private OrderFeedbackService orderfeedbackService;
	
	public String insertOrderFeedbackRecords(OrderFeedback orderf)
	{
		orderfeedbackService.addOrderFeedback(orderf);
		return "Thanks for your Feedback";
	}
	//-------------------------------------------------------------------------------------------------------
	@RequestMapping(value = "/add", //
            method = RequestMethod.POST, //
            produces = { MediaType.APPLICATION_JSON_VALUE, //
                    MediaType.APPLICATION_XML_VALUE })
    @ResponseBody
	public OrderFeedback createOrderFeedback(@RequestBody OrderFeedback of) {
		return orderfeedbackService.addOrderFeedback1(of);	
	}
	@RequestMapping(value = "/display", //
            method = RequestMethod.GET, //
            produces = { MediaType.APPLICATION_JSON_VALUE, //
                    MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	public List<OrderFeedback> getOrderFeedbacks()
	{
		return orderfeedbackService.getOrderFeedbacks();
	}
	@RequestMapping(value = "/remove/{feedbackId}", //
            method = RequestMethod.DELETE, //
            produces = { MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	public void deleteOrderFeedback(@PathVariable("feedbackId") Long id) {
		orderfeedbackService.deleteOrderFeedback(id);
	}

}