package com.medical.bootjpa.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;
import com.medical.bootjpa.entity.Customer;
import com.medical.bootjpa.service.CustomerService;
@RestController
public class CustomerController {
	@Autowired
	private CustomerService customerService;
	public String insertCustomerRecords(Customer cust)
	{
		customerService.addCustomer(cust);
		return "One Customer Record Registered";
	}
	public String getCustomerLoginPassword(Long id)
	{
		return customerService.selectCustomerById(id);
	}
	public String getCustomerById(Long id)
	{
		Customer cust=customerService.getCustomerById(id);
		return cust.getCustomerCity();
	}
}