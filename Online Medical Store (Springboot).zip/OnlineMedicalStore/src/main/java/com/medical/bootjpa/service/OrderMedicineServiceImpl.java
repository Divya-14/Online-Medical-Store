package com.medical.bootjpa.service;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.medical.bootjpa.entity.OrderMedicine;
import com.medical.bootjpa.repository.OrderMedicineRepository;
@Service("ordermedicineServiceImpl")
public class OrderMedicineServiceImpl implements  OrderMedicineService{
	@Autowired	
	private OrderMedicineRepository ordermedicineRepository;
	@Override
	public void addOrderMedicine(OrderMedicine orderm) {
		ordermedicineRepository.save(orderm);
	}
	@Override
	public void updatePaymentStatusById(String paystatus,Long id) {
		ordermedicineRepository.updatePaymentStatusById(paystatus,id);	
	}
	@Override
	public OrderMedicine getOrderMedicineById(Long id) {
		OrderMedicine orderm=ordermedicineRepository.findOne(id);
		return orderm;
	}
	//-----------------------------------------------------------------------------------------------------------------
	@Override
	public OrderMedicine addOrderMedicine1(OrderMedicine om) {
			return ordermedicineRepository.save(om);
	}
	@Override
	public List<OrderMedicine> getOrderMedicines() {
	return ordermedicineRepository.findAll();
	}
	@Override
	public void deleteOrderMedicine(Long id) {
		ordermedicineRepository.delete(id);	
	}
	
}