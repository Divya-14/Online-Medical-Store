package com.medical.bootjpa.controller;
import java.util.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import com.medical.bootjpa.entity.MedicalStore;
import com.medical.bootjpa.service.MedicalService;
@RestController
@RequestMapping(value = "/MedicalStore")
public class MedicalController {
	@Autowired
	private MedicalService medicalstoreService;
	public String insertMedicalStoreRecords(MedicalStore medical)
	{
		medicalstoreService.addMedicalStore(medical);
		return "One MedicalStore Record Registered";
	}
	public void getStoreCity(String city)
	{
		ArrayList<MedicalStore> stores=medicalstoreService.selectStoreByCity(city);
		for(MedicalStore m:stores)
		{
			System.out.println(m.getStoreName()+"--"+m.getStoreAdd());
		}		
	}
	public void fetchAllMedicalStore()
	{
		ArrayList<MedicalStore> al=medicalstoreService.fetchAll();
		for(MedicalStore medical:al) {
			System.out.println(medical.getStoreId()+"--"+medical.getStoreName()+"--"+medical.getCity()+"--"+medical.getEmail()+"--"+medical.getPhone()+"--"+medical.getStoreAdd());
		}
	}
	public Long getMedicalStoreId(Long id)
	{
		return medicalstoreService.selectMedicalStoreById(id);
	}
	//--------------------------------------------------------------------------------------------------------------------------------------------------------------------
	@RequestMapping(value = "/add", //
            method = RequestMethod.POST, //
            produces = { MediaType.APPLICATION_JSON_VALUE, //
                    MediaType.APPLICATION_XML_VALUE })
    @ResponseBody
	public MedicalStore createMedicalStore(@RequestBody MedicalStore m) {
		return medicalstoreService.addMedicalStore1(m);	
	}
	@RequestMapping(value = "/display", //
            method = RequestMethod.GET, //
            produces = { MediaType.APPLICATION_JSON_VALUE, //
                    MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	public List<MedicalStore> getMedicalStores()
	{
		return medicalstoreService.getMedicalStores();
	}
	@RequestMapping(value = "/remove/{storeId}", //
            method = RequestMethod.DELETE, //
            produces = { MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	public void deleteMedicalStore(@PathVariable("storeId") Long id) {
		medicalstoreService.deleteMedicalStore(id);
	}
}