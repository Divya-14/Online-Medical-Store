package com.medical.bootjpa.controller;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import com.medical.bootjpa.entity.OrderMedicine;
import com.medical.bootjpa.service.OrderMedicineService;
@RestController
@RequestMapping(value = "/OrderMedicine")
public class OrderMedicineController {
	@Autowired
	private OrderMedicineService ordermedicineService;
	public String insertOrderMedicineRecords(OrderMedicine orderm)
	{
		ordermedicineService.addOrderMedicine(orderm);
		return "One OrderMedicine Record Registered";
	}
	public void updateOrderMedicine(String paystatus,Long id)
	{
		ordermedicineService.updatePaymentStatusById(paystatus,id);
		
	}
	public int getOrderMedicineById(Long id)
	{
		OrderMedicine orderm=ordermedicineService.getOrderMedicineById(id);
		return orderm.getBillAmount();
	}
	//---------------------------------------------------------------------------------------------------------
	@RequestMapping(value = "/add", //
            method = RequestMethod.POST, //
            produces = { MediaType.APPLICATION_JSON_VALUE, //
                    MediaType.APPLICATION_XML_VALUE })
    @ResponseBody
	public OrderMedicine createOrderMedicine(@RequestBody OrderMedicine om) {
		return ordermedicineService.addOrderMedicine1(om);	
	}
	@RequestMapping(value = "/display", //
            method = RequestMethod.GET, //
            produces = { MediaType.APPLICATION_JSON_VALUE, //
                    MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	public List<OrderMedicine> getOrderMedicines()
	{
		return ordermedicineService.getOrderMedicines();
	}
	@RequestMapping(value = "/remove/{OrderId}", //
            method = RequestMethod.DELETE, //
            produces = { MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	public void deleteOrderMedicine(@PathVariable("OrderId") Long id) {
		ordermedicineService.deleteOrderMedicine(id);
	}	
}