package com.medical.bootjpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MedicalStore1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
