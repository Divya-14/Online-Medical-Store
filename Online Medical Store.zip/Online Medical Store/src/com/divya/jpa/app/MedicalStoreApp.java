package com.divya.jpa.app;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.*;

import javax.persistence.Column;

import com.divya.jpa.controller.CustomerController;
import com.divya.jpa.controller.MedicalController;
import com.divya.jpa.controller.OrderFeedbackController;
import com.divya.jpa.controller.OrderMedicineController;
import com.divya.jpa.entity.Customer;
import com.divya.jpa.entity.MedicalStore;
import com.divya.jpa.entity.OrderFeedback;
import com.divya.jpa.entity.OrderMedicine;

public class MedicalStoreApp 
{
	Long dummyId=null;
	Long dummy1=null;
	public void getMedicalStoreDetails(Scanner sc)
	{
		System.out.println("Enter MedicalStoreName:");
		String sname=sc.next();
		System.out.println("Enter  StoreAddress:");
		String add=sc.next();
		System.out.println("Enter City:");
		String city=sc.next();
		System.out.println("Enter phone:");
		String phone=sc.next();
		System.out.println("Enter Email:");
		String email=sc.next();
		MedicalStore  medicals=new MedicalStore();
		medicals.setStoreName(sname);
		medicals.setStoreAdd(add);
		medicals.setCity(city);
		medicals.setPhone(phone);
		medicals.setEmail(email);
		MedicalController mc=new MedicalController();
		mc.insertMedicalStore(medicals);
		System.out.println("MedicalStore Registered Successfully:");

	}
	public void getCustomerDetails(Scanner sc)
	{
		System.out.println("Enter Customer Name:");
		String cname=sc.next();
		System.out.println("Enter Customer Phone :");
		String cphone=sc.next();
		System.out.println("Enter Customer Email");
		String cemail=sc.next();
		System.out.println("Enter Customer Address:");
		String cadd=sc.next();
		System.out.println("Enter Customer City:");
		String ccity=sc.next();
		System.out.println("Enter Customer Password:");
		String cpsw=sc.next();

		Customer cust=new Customer();
		cust.setCustomerName(cname);
		cust.setCustomerPhone(cphone);
		cust.setCustomerEmail(cemail);
		cust.setCustomerAddress(cadd);
		cust.setCustomerCity(ccity);
		cust.setCustomerPassword(cpsw);
		CustomerController cc=new CustomerController();
		cc.insertCustomer(cust);
		System.out.println(" Customer Registered Sucessfully.");
	}
	public boolean loginCustomer(Scanner sc)
	{
		System.out.println("Customer Id:");
		Long custid=sc.nextLong();
		dummyId=custid;
		System.out.println("Customer Password:");
		String cpsw=sc.next();
		CustomerController cc=new CustomerController();
		String originalpwd=cc.getCustomerLoginPassword(custid);
		if(originalpwd.equals(cpsw))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	public void  DisplayMedicalStoreDetails(Scanner sc)
	{
		MedicalController dis=new MedicalController();
		dis.displayByCity();
	}
	public void  getDisplayCustomerCityDetails(Scanner sc)
	{
		CustomerController dis=new CustomerController();
		dis.displayById(dummyId);

	}
	/*	public void getMedicalStoreDetailsInHyd(Scanner sc)
	{
		MedicalController mc=new MedicalController();
		mc.displayMedicalStoreByHyd();
	}*/

	public void getOrderMedicineDetails(Scanner sc)
	{
		MedicalController mc=new MedicalController();
		mc.displayMedicalStoreByHyd();
		int sum=0;
		System.out.println("please select storeId:");
		Long storeId=sc.nextLong();
		Long dummy1=storeId;
		System.out.println("Following medicines are available-");
		System.out.println("1. paracetamol----rs 5");
		System.out.println("2. coldact----rs 8");
		System.out.println("3. vicks----rs 4");
		System.out.println("4.sinarest----rs 6");
		System.out.println("5.Dolo----rs 3");
		HashMap<Integer,Integer> hm=new HashMap<Integer,Integer>();
		hm.put(1,5);
		hm.put(2,8);
		hm.put(3,4);
		hm.put(4,6);
		hm.put(5,3);
		@SuppressWarnings("unused")
		String ch2="y";
		char c1;
		do
		{
			System.out.println("please enter medicine name:");
			String mname=sc.next();
			System.out.println("please enter quantity:");
			int quantity=sc.nextInt();
			@SuppressWarnings("deprecation")
			int price=quantity*hm.get(new Integer(mname));
			sum=sum+price;
			System.out.println("Total BillAmount="+sum);
			System.out.println("Do you want to continue:");
			c1=sc.next().charAt(0);
		}
		while(c1=='y');

		Date date=new Date();
		SimpleDateFormat formatter=new SimpleDateFormat("MM/dd/yyyy");
		String strDate=formatter.format(date);
		Calendar c=Calendar.getInstance();
		System.out.println(c.getTime());
		@SuppressWarnings("unused")

		OrderMedicine om=new  OrderMedicine();
		om.setCustomerId(dummyId);
		om.setBillAmount(sum);
		om.setStoreId(dummy1);
		om.setDate(strDate);
		om.setPaymentStatus("No");
		OrderMedicineController omc=new OrderMedicineController();
		omc.insertOrderMedicine(om);
		System.out.println(" ordered medicine successfully");
	}

	public void getOrderPaymentDetails(Scanner sc)
	{
		System.out.println("please Enter CustomerId");
		Long custid=sc.nextLong();
		System.out.println("please Enter BillAmount");
		String ba=sc.next();
		System.out.println("please Select PaymentMode(OnlineBanking/UPI/Cash)");
		String pm=sc.next();
		if(pm.equals("Cash")||pm.equals("UPI")||pm.equals("OnlineBanking"))
		{
			OrderMedicineController omc=new OrderMedicineController();
			omc.updateStatus(custid);
		}
		System.out.println("Thanks for your Payment");
	}
	public void getOrderFeedbackDetails(Scanner sc)
	{
		System.out.println("Enter your CustomerId");
		String custid=sc.next();
		System.out.println("Enter your Feedback:");
		String fb=sc.next();
		OrderFeedback of=new OrderFeedback();
		of.setCustomerId(dummyId);
		of.setFeedback(fb);
		OrderFeedbackController ofc=new OrderFeedbackController();
		ofc.insertOrderFeedback(of);
		System.out.println("Thanks for your Feedback...");
	}
	public static void main(String[] args)
	{
		MedicalStoreApp app=new MedicalStoreApp();
		Scanner sc=new Scanner(System.in);
		System.out.println("Online Medical Store:");
		System.out.println("---------------------");
		char ca;
		do
		{
			try
			{
				System.out.println("1.Admin");
				System.out.println("2.Customer");
				System.out.println("3.Exit");
				System.out.println("Please Select Option:");
				int opt=sc.nextInt();
				if(opt==1)
				{
					System.out.println("Admin Id:");
					String id=sc.next();
					System.out.println("Admin Password:");
					String pwd=sc.next();
					if(id.equals("admin")&&pwd.equals("admin"))
					{
						char ca1;
						do
						{
							try 
							{
								System.out.println("1.Medical Store Registration:");
								System.out.println("2.Get Medical Store details  by city");
								System.out.println("3.Admin Logout");
								System.out.println("Please select option:");
								int opt1=sc.nextInt();
								char c;								
								do
								{
									if(opt1==1)
									{	
										app.getMedicalStoreDetails(sc);
									}
									else if(opt1==2)
									{
										app.DisplayMedicalStoreDetails(sc);
									}
									else if(opt1==3)
									{
										break;
									}
									System.out.println("Do you want to continue:");
									c=sc.next().charAt(0);
								}
								while(c=='y');
							}
							catch(InputMismatchException e)
							{
								System.out.println("Invalid Input");
								System.out.println("please enter 1 and 2  option");
							}
							System.out.println("Do you want to continue:");
							ca1=sc.next().charAt(0);
						}
						while(ca1=='y');
					}
				}
					else if(opt==2)
					{	
						char ca2;
						do
						{
							System.out.println("1.Customer Registration");
							System.out.println("2.Customer Login");
							System.out.println("3.Customer Logout");
							System.out.println("Please select option:");
							int copt=sc.nextInt();
							if(copt==1)
							{
								app.getCustomerDetails(sc);
							}
							else if(copt==2)
							{
								if(app.loginCustomer(sc))
								{

									app.getDisplayCustomerCityDetails(sc);
								}
								System.out.println("1.Order Medicine");
								System.out.println("2.Order Payment");
								System.out.println("3.Medical Store Feedback ");
								System.out.println("please select option:");
								int ch=sc.nextInt();
								if(ch==1) 
								{
									//app.getMedicalStoreDetailsInHyd(sc);
									app.getOrderMedicineDetails(sc);
								}
								else if(ch==2)
								{
									app.getOrderPaymentDetails(sc);
								}
								else if(ch==3)
								{
									app.getOrderFeedbackDetails(sc);
								}
							} 
							else if(copt==3)
							{
								break;
							}

							else 
							{
								System.out.println("invalid option:");
								System.out.println("please enter 1 and 2 options");
							}
							System.out.println("Do you want to continue:");
							ca2=sc.next().charAt(0);
						}
						while(ca2=='y');
					}
					else if(opt==3)
					{
						break;
					}
					else
					{
						System.out.println("Invalid option");
						System.out.println("please enter 1 and 2 options");
					}	
				
			}
			catch(InputMismatchException e)
			{
				System.out.println("Invalid Input");
				System.out.println("please enter 1 and 2 options");
			}
			System.out.println("Do you want to continue:1");
			ca=sc.next().charAt(0);
		}
		while(ca=='y');
	}
}