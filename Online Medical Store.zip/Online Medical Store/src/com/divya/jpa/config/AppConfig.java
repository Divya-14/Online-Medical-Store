package com.divya.jpa.config;
import javax.persistence.*;
public class AppConfig {
	private static AppConfig instance = null;	
	private AppConfig() {
		
	}
	public static AppConfig getObject() {
		if(instance==null) {
			instance = new AppConfig();
		}
		return instance;
	}
	public EntityManager getEntityManager() {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("TestPersistence");
		EntityManager em=emf.createEntityManager();
		return em;
	}
}