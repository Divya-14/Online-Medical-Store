package com.divya.jpa.controller;

import com.divya.jpa.entity.Customer;
import com.divya.jpa.service.CustomerService;
import com.divya.jpa.service.CustomerServiceImpl;

public class CustomerController {
	CustomerService service=null;
	public CustomerController()
	{
		service=new CustomerServiceImpl();
	}
	public void insertCustomer(Customer sc)
	{
		service.addCustomer(sc);
	}
	public String getCustomerLoginPassword(Long id)
	{
		return service.loginCustomerPassword(id);
	}
	public void displayById(Long custid)
	{
		service.displayCustomerCity(custid);
	}
}