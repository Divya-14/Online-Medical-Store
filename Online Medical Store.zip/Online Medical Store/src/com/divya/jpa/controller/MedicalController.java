package com.divya.jpa.controller;

import com.divya.jpa.entity.MedicalStore;
import com.divya.jpa.service.MedicalServiceImpl;
import com.divya.jpa.service.MedicalService;
public class MedicalController 

{
	MedicalService service=null;
	public  MedicalController()
	{
		service = new MedicalServiceImpl();
	}
	public void insertMedicalStore(MedicalStore sc)
	{
		service.addMedicalStore(sc);
	}
	public void displayByCity()
	{
		service.displayAllMedicalStore();
		System.out.println("done");
	}
	public void displayMedicalStoreByHyd()
	{
		service.displayMedicalStoreByHyd();
	}
}