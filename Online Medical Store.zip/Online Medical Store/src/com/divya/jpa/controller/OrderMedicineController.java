package com.divya.jpa.controller;

import com.divya.jpa.entity.OrderMedicine;
import com.divya.jpa.service.OrderMedicineService;
import com.divya.jpa.service.OrderMedicineServiceImpl;
public class OrderMedicineController 

{
	OrderMedicineService service=null;
	public  OrderMedicineController()
	{
		service = new OrderMedicineServiceImpl();
	}
	public void insertOrderMedicine(OrderMedicine sc)
	{
		service.addOrderMedicine(sc);
	}
	public void updateStatus(Long custid) {
		service.updatePaymentStatus(custid);
		
	}
}