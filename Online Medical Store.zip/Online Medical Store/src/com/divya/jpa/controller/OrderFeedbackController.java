package com.divya.jpa.controller;

import com.divya.jpa.entity.OrderFeedback;
import com.divya.jpa.service.OrderFeedbackService;
import com.divya.jpa.service.OrderFeedbackServiceImpl;

public class OrderFeedbackController {
	OrderFeedbackService service=null;
	public OrderFeedbackController()
	{
		service=new OrderFeedbackServiceImpl();
	}
	public void insertOrderFeedback(OrderFeedback sc)
	{
		service.addOrderFeedback(sc);
	}
}