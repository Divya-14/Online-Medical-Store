package com.divya.jpa.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name ="OrderFeedback_REG")
@NamedQuery(name = "findOrderFeedbackrecords", query = "select sr from OrderFeedback sr")
public class OrderFeedback {
	@Id //primary key
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long feedbackId;
	@Column (name= "Customer_Id")
	private Long customerId;
	@Column (name= "Feedback")
	private String feedback;

	public Long getFeedbackId() {
		return feedbackId;
	}

	public void setFeedbackId(Long feedbackId) {
		this.feedbackId = feedbackId;
	}

	public Long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}

	public String getFeedback() {
		return feedback;
	}

	public void setFeedback(String feedback) {
		this.feedback = feedback;
	}

}