package com.divya.jpa.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name = "OrderMedicine_REG")
@NamedQuery(name = "findOrderMedicinerecords", query = "select sr from OrderMedicine sr")
public class OrderMedicine {
	@Id //primary key
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long OrderId;
	@Column (name= "Customer_Id")
	private Long customerId;
	@Column (name= "Store_Id")
	private Long storeId;
	@Column (name= "BillAmount")
	private int billAmount;
	@Column (name= "PaymentStatus")
	private String paymentStatus;
	@Column (name= "Date")
	private String date;
	public Long getOrderId() {
		return OrderId;
	}
	public void setOrderId(Long orderId) {
		OrderId = orderId;
	}
	public Long getCustomerId() {
		return customerId;
	}
	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}
	public Long getStoreId() {
		return storeId;
	}
	public void setStoreId(Long storeId) {
		this.storeId = storeId;
	}
	public int getBillAmount() {
		return billAmount;
	}
	public void setBillAmount(int billAmount) {
		this.billAmount = billAmount;
	}
	public String getPaymentStatus() {
		return paymentStatus;
	}
	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}


}