package com.divya.jpa.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


@Entity
@Table(name ="Customer")
@NamedQuery(name = "findCustomerrecords", query = "select cust from Customer cust")
public class Customer
{
	@Id //primary key
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long customerId;
	@Column (name= "Customer_Name")
	private String customerName;
	@Column (name= "Customer_Phone")
	private String customerPhone;
	@Column (name= "Customer_Address")
	private String customerAddress;
	@Column (name= "Customer_Email")
	private String customerEmail;
	@Column (name= "Customer_City")
	private String customerCity;
	@Column (name= "Customer_Password")
	private String customerPassword;
	
	public Long getCustomerId() {
		return customerId;
	}
	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCustomerPhone() {
		return customerPhone;
	}
	public void setCustomerPhone(String customerPhone) {
		this.customerPhone = customerPhone;
	}
	public String getCustomerAddress() {
		return customerAddress;
	}
	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}
	public String getCustomerEmail() {
		return customerEmail;
	}
	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}
	public String getCustomerCity() {
		return customerCity;
	}
	public void setCustomerCity(String customerCity) {
		this.customerCity = customerCity;
	}
	public String getCustomerPassword() {
		return customerPassword;
	}
	public void setCustomerPassword(String customerPassword) {
		this.customerPassword = customerPassword;
	}

}