package com.divya.jpa.service;

import com.divya.jpa.entity.MedicalStore;
public interface MedicalService 
{
	public void addMedicalStore(MedicalStore ms);
	public void displayAllMedicalStore();
	public void displayMedicalStoreByHyd();

}