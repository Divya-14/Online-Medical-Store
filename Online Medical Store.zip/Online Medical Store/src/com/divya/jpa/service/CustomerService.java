package com.divya.jpa.service;

import com.divya.jpa.entity.Customer;

public interface CustomerService
{
	public void addCustomer(Customer cust);
	public String loginCustomerPassword(Long cid);
	public void displayCustomerCity(Long custid);

}