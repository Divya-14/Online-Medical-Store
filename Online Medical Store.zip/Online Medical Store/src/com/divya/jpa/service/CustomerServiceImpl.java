package com.divya.jpa.service;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.divya.jpa.config.AppConfig;
import com.divya.jpa.entity.Customer;

public class CustomerServiceImpl implements CustomerService
{

	@Override
	public void addCustomer(Customer sc)
	{EntityManager em=AppConfig.getObject().getEntityManager();
	em.getTransaction().begin();
	em.persist(sc);
	em.getTransaction().commit();		
	}

	@Override
	public String loginCustomerPassword(Long cid) {
		EntityManager em=AppConfig.getObject().getEntityManager();
		Query q=em.createQuery("select sr.customerPassword from Customer sr where sr.customerId="+cid);
		Object o=q.getSingleResult();
		String pwd=(String)o;
		return pwd;
	}

	@Override
	public void displayCustomerCity(Long custid) {

		EntityManager em=AppConfig.getObject().getEntityManager();	
		Scanner sc=new Scanner(System.in);
		Query q=em.createQuery("select sr from Customer sr where sr.customerId='"+custid+"'");
		List<Customer> l=q.getResultList();
		Iterator itr = l.iterator();
		while(itr.hasNext())
		{
			Object o=itr.next();
			Customer s=(Customer)o;
			System.out.println(s.getCustomerCity());

		}


	}

	
	}