package com.divya.jpa.service;

import javax.persistence.EntityManager;

import com.divya.jpa.config.AppConfig;
import com.divya.jpa.entity.OrderFeedback;

public class OrderFeedbackServiceImpl implements  OrderFeedbackService{

	@Override
	public void addOrderFeedback(OrderFeedback sc) {
		EntityManager em=AppConfig.getObject().getEntityManager();
		em.getTransaction().begin();
		em.persist(sc);
		em.getTransaction().commit();

		
	}

}