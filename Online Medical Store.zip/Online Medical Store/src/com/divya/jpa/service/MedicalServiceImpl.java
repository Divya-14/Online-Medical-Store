package com.divya.jpa.service;

import java.util.*;
import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.divya.jpa.config.AppConfig;
import com.divya.jpa.entity.Customer;
import com.divya.jpa.entity.MedicalStore;
public class MedicalServiceImpl implements MedicalService
{
	@Override
	public void addMedicalStore(MedicalStore sc) 
	{
		EntityManager em=AppConfig.getObject().getEntityManager();	
		em.getTransaction().begin();
		em.persist(sc);
		em.getTransaction().commit();
	}
	@Override
	public void displayAllMedicalStore()
	{
		EntityManager em=AppConfig.getObject().getEntityManager();	
		Scanner sc=new Scanner(System.in);
		System.out.println("Please Enter City");
		String city=sc.next();
		Query q=em.createQuery("select sr from MedicalStore sr where sr.city='"+city+"'");
		List<MedicalStore> l=q.getResultList();
		Iterator itr = l.iterator();
		while(itr.hasNext())
		{
			Object o=itr.next();
			MedicalStore s=(MedicalStore)o;
			System.out.println(s.getStoreId()+"----"+s.getCity()+"---"+s.getStoreName()+"---"+s.getPhone()+"----"+s.getStoreAdd()+"---"+s.getEmail());
		}
	}
	/*	@Override
	public void displayMedicalStoreByHyd(Long custid) {
		EntityManager em=AppConfig.getObject().getEntityManager();	
		Customer c=em.find(Customer.class,custid);
		String city=c.getCustomerCity();
		Query q1=em.createQuery("select sr from Customer sr where sr.city='"+custid+"'");

		List<Customer> l1=q1.getResultList();
		Iterator itr1 = l1.iterator();
		while(itr1.hasNext())
		{
			Object o1=itr1.next();
			Customer s1=(Customer)o1;
		String a=s1.getCity();
		}*/
	/*MedicalStore ms=em.find(MedicalStore.class, city);
		String s1=ms.getCity();
		if(city.equals(s1))
		{
			Query q=em.createQuery("select sr from MedicalStore sr where sr.city='"+s1+"'");
			List<MedicalStore> l=q.getResultList();
			Iterator itr = l.iterator();
			while(itr.hasNext())
			{
				Object o=itr.next();
				MedicalStore s2=(MedicalStore)o;
				System.out.println(s2.getStoreId()+"----"+s2.getCity()+"---"+s2.getStoreName()+"---"+s2.getPhone()+"----"+s2.getStoreAdd()+"---"+s2.getEmail());
			}}
		}*/
	public void displayMedicalStoreByHyd()
	{
		Scanner sr=new Scanner(System.in);
		EntityManager em=AppConfig.getObject().getEntityManager();	
		System.out.println("please enter city");
		String scity=sr.next();
		Query q1=em.createQuery("select sr from MedicalStore sr where sr.city='"+scity+"' ");
		List<MedicalStore> l=q1.getResultList();
		Iterator<MedicalStore> itr = l.iterator();
		while(itr.hasNext())
		{
			Object o=itr.next();
			MedicalStore s2=(MedicalStore)o;
			System.out.println(s2.getStoreId()+"----"+s2.getCity()+"---"+s2.getStoreName()+"---"+s2.getPhone()+"----"+s2.getStoreAdd()+"---"+s2.getEmail());
		}
	}
}