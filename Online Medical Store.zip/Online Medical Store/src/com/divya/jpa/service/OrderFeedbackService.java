package com.divya.jpa.service;

import com.divya.jpa.entity.OrderFeedback;

public interface OrderFeedbackService {
public void addOrderFeedback(OrderFeedback sc);
}