package com.divya.jpa.service;

import com.divya.jpa.entity.OrderMedicine;
public interface OrderMedicineService
{
	public void addOrderMedicine(OrderMedicine sc);
	public void updatePaymentStatus(Long custid);
}