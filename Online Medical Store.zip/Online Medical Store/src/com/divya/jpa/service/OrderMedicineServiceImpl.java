package com.divya.jpa.service;

import javax.persistence.EntityManager;

import com.divya.jpa.config.AppConfig;
import com.divya.jpa.entity.Customer;
import com.divya.jpa.entity.OrderMedicine;

public class OrderMedicineServiceImpl implements OrderMedicineService
{

	@Override
	public void addOrderMedicine(OrderMedicine sc) {

		EntityManager em=AppConfig.getObject().getEntityManager();	
		em.getTransaction().begin();
		em.persist(sc);
		em.getTransaction().commit();
	}
	@Override
	public void updatePaymentStatus(Long custid) {
		EntityManager em=AppConfig.getObject().getEntityManager();	
		OrderMedicine om=em.find(OrderMedicine.class,custid);
		om.setPaymentStatus("Yes");
		em.getTransaction().begin();
		em.persist(om);
		em.getTransaction().commit();	

	}
}